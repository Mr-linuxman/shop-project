<?php
function resertnew($newpass,$pass){
$mysqli =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
$mysqli->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

if(1){
    $q = 'select * from reset where pass = ?;';
    $st = $mysqli->prepare($q);
    $st->bindValue(1,$pass,PDO::PARAM_STR);
    $st->execute();
    $l =($st->fetchAll());
    if(isset($l[0])){
        $date1 =  ($l[0]['date']);
        $daar1 = (explode("/",$date1));
        $date2 = date("Y/m/d/H/i");
        $daar2 = explode("/",$date2);
        if($daar1[3] == $daar2[3]){
            $ekh =  $daar2[4] - $daar1[4];
            if($ekh > 5){
                return('code is obsolete');
                die();
            }
        }else{
            return('code is obsolete');
            die();
        }
        $mysqli2 =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
        $mysqli2->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $q = "update admin set apass= ? where Email = '".$l[0]['email']."' ;";
        $st = $mysqli2->prepare($q);
        $st->bindValue(1,$newpass,PDO::PARAM_STR);
        $st->execute();
        $q = 'delete from reset where pass = ? ;';
        $st2 = $mysqli->prepare($q);
        $st2->bindValue(1,$pass,PDO::PARAM_STR);
        $st2->execute();
        return("changed");
    }else{
        return('User not found');
    }
    }
}


?>
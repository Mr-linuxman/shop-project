<?php 
try {
    $mysqli =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
    $mysqli->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(PDOException $f){
    echo $f->getMessage();
}
try{
    $q = "ALTER TABLE products  AUTO_INCREMENT = 1;";
    $st = $mysqli->prepare($q);
    $st->execute();
}catch(PDOException){

}
function get_lp($page){
    if(is_numeric($page)){

    }else{
        echo 'number error';
        die();
    }
    global $mysqli;
    $num = (6*$page)-6;
    $q = "select * from products order by pid desc limit $num,6;";
    $st = $mysqli->prepare($q);
    $st->execute();
    return(json_encode($st->fetchAll()));
}
function create_cookie($user,$pass){
    $key =  base64_encode(bin2hex($user));
    $hashedkey = md5($key);
    $data = "$user+$pass";
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, "AES-256-CBC", $hashedkey, 0,$iv);
    return $encrypted ; 
}
function singin($user,$pass){
    try {
        $mysqli2 =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
        $mysqli2->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }catch(PDOException $f){
        echo $f->getMessage();
    }
    $q = "select * from admin where auser = ? ;";
    $st = $mysqli2->prepare($q);
    $st->bindValue(1,$user,PDO::PARAM_STR);
    $st->execute();
    $info = ($st->fetchAll());
    if(isset($info[0])){
        if($info[0]['apass'] == $pass){
            $cookie = create_cookie($user,$pass);
            $q2 = "update admin set cookie = '$cookie' where auser = ? and apass = '$pass';";
            $st = $mysqli2->prepare($q2);
            $st->bindValue(1,$user,PDO::PARAM_STR);
            $st->execute();
            setcookie("cookie",$cookie);
            return(json_encode("loged in"));
        }else{
             return(json_encode('user or password is false'));
        }
    }else{
        return(json_encode('user or password is false'));
    }

}
function addproduct($name,$describe,$profile){
    global $mysqli;
    $q = 'insert into products (pname,pdescribe,profile) values (?,?,?);';
    $st = $mysqli->prepare($q);
    $st->bindValue(1,$name,PDO::PARAM_STR);
    $st->bindValue(2,$describe,PDO::PARAM_STR);
    $st->bindValue(3,$profile,PDO::PARAM_STR);
    try{
        $st->execute();
        echo 'added';
    }catch(PDOException $f){
        echo 'it is added ago';
    }
}
function deleteproduct($name){
    global $mysqli;
    $q = "delete from products where pname = ?;";
    $st = $mysqli->prepare($q);
    $st->bindValue(1,$name,PDO::PARAM_STR);
    $st->execute();
    echo json_encode('deleted');
}

function add_menu($name,$des,$price,$type){
    global $mysqli;
    $q = "insert into menu(mname,sdescribe,price,type) values(?,?,?,?);";
    $st = $mysqli->prepare($q);
    $st->bindValue(1,$name,PDO::PARAM_STR);
    $st->bindValue(2,$des,PDO::PARAM_STR);
    $st->bindValue(3,$price,PDO::PARAM_STR);
    $st->bindValue(4,$type,PDO::PARAM_STR);
    try{
        $st->execute();
    }catch(PDOException $c){
        echo 'this product is exist';
    }
}

function deletemenu($name){
    global $mysqli;
    $q = "delete from menu where mname = ?;";
    $st = $mysqli->prepare($q);
    $st->bindValue(1,$name,PDO::PARAM_STR);
    $st->execute();
    echo json_encode('deleted sesecfully');
}
function istrue($coock){
    try {
        $mysqli2 =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
        $mysqli2->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }catch(PDOException $f){
        echo $f->getMessage();
    }
    $q = "select * from admin where cookie = ? ;";
    $st = $mysqli2->prepare($q);
    $st->bindValue(1,$coock,PDO::PARAM_STR);
    $st->execute();
    if(isset($st->fetchAll()[0])){
        return true;
    }else{
        return false;
    }
}
?>
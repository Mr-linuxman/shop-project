<!DOCTYPE html>
<html lang="de">

<head>
   <title> ROMIANI </title>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <meta name="theme-color">
   <!-- style -->
   <link rel="stylesheet" href="style/font-awesome/css/all.min.css">
   <link rel="stylesheet" href="style/style.css">
   <!-- script -->
   <script src="script/Mushroom.min.js"></script>
</head>

<body>
   <!-- header -->
   <header>
      <div>
         <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000">
            <path fill="currentColor" d="M183.33,825L183.33,425C183.33,375,133.33,325,83.33,325L83.33,725C83.33,775,133.33,825,183.33,825z" />
            <path fill="currentColor" d="M216.67,825L216.67,425C216.67,375,266.67,325,316.67,325L316.67,725C316.67,775,266.67,825,216.67,825z" />
            <path fill="currentColor" d="M783.33,825L783.33,425C783.33,375,733.33,325,683.33,325L683.33,725C683.33,775,733.33,825,783.33,825z" />
            <path fill="currentColor" d="M816.67,825L816.67,425C816.67,375,866.67,325,916.67,325L916.67,725C916.67,775,866.67,825,816.67,825z" />
            <path fill="var(--primary-fixed-dim)" d="M483.33,825L483.33,275C483.33,225,433.33,175,383.33,175L383.33,725C383.33,775,433.33,825,483.33,825z" />
            <path fill="var(--primary-fixed-dim)" d="M516.67,825L516.67,275C516.67,225,566.67,175,616.67,175L616.67,725C616.67,775,566.67,825,516.67,825z" />
         </svg>
         <div><span class="p">R</span>OMIANI</div>
      </div>
      <div>
         <div onclick="Darkmode()" class="ripple-p ic desx">
            <i class="fad fa-moon-over-sun"></i>
         </div>
         <div onclick="Menu()" class="ripple-p ic">
            <i class="fad fa-bars"></i>
         </div>
      </div>
   </header>
   <!-- backdrop -->
   <backdrop id="menuBackdrop"></backdrop>
   <!-- menu -->
   <menu>
      <menu-header>
         <div class="color"></div>
         <div class="title">
            ROMIANI
         </div>
      </menu-header> <menu-body>
         <div class="list">
            <label class="ripple-p" oninput="Darkmode()"> <span><span class="p">D</span>arkmode</span> <input id="darkmode" type="checkbox" class="switch"> </label>
         </div>
         <div class="hwr">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
               <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
            </svg>
         </div>
         <div class="list">
            <a class="ripple">
               <span> <span class="p">T</span>elegram </span> <i class="fab fa-telegram"></i>
            </a>
            <a class="ripple">
               <span><span class="p">X</span> (<span class="p">T</span>witter)</span>
               <i class="fab fa-x-twitter"></i>
            </a>
            <a class="ripple">
               <span><span class="p">I</span>nstagram</span>
               <i class="fab fa-instagram"></i>
            </a>
            <a class="ripple">
               <span><span class="p">F</span>acebook</span>
               <i class="fab fa-facebook-f"></i>
            </a>
            <a class="ripple">
               <span><span class="p">L</span>inkedin <span class="p">I</span>n</span>
               <i class="fab fa-linkedin-in"></i>
            </a>
         </div>
         <div class="hwr">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
               <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
            </svg>
         </div>
         <div class="list">
            <a class="ripple">
               <span><span class="p">E</span>mail</span>
               <i class="fas fa-envelope"></i>
            </a>
            <a class="ripple">
               <span><span class="p">P</span>hone <span class="p">N</span>umber</span>
               <span class="fa fas fa-phone"></span>
            </a>
         </div>
      </menu-body>
   </menu>
   <!-- main -->
   <main>
      <!-- start -->
      <div class="start">
         <div class="logo">
            <div>
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000">
                  <path fill="currentColor" d="M183.33,825L183.33,425C183.33,375,133.33,325,83.33,325L83.33,725C83.33,775,133.33,825,183.33,825z" />
                  <path fill="currentColor" d="M216.67,825L216.67,425C216.67,375,266.67,325,316.67,325L316.67,725C316.67,775,266.67,825,216.67,825z" />
                  <path fill="currentColor" d="M783.33,825L783.33,425C783.33,375,733.33,325,683.33,325L683.33,725C683.33,775,733.33,825,783.33,825z" />
                  <path fill="currentColor" d="M816.67,825L816.67,425C816.67,375,866.67,325,916.67,325L916.67,725C916.67,775,866.67,825,816.67,825z" />
                  <path fill="var(--primary-fixed-dim)" d="M483.33,825L483.33,275C483.33,225,433.33,175,383.33,175L383.33,725C383.33,775,433.33,825,483.33,825z" />
                  <path fill="var(--primary-fixed-dim)" d="M516.67,825L516.67,275C516.67,225,566.67,175,616.67,175L616.67,725C616.67,775,566.67,825,516.67,825z" />
               </svg>
            </div>
            <div>
               ROMIANI
            </div>
         </div>
         <div class="hwr">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
               <path fill="none" stroke="var(--primary-fixed-dim)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
            </svg>
         </div>
         <blockquote>
            Wir sind nicht die <span class="p">Besten</span> aber wir gehören zu den Besten
         </blockquote>
      </div>
      <!-- article -->
      <article class="about">
         <!-- home -->
         <section>
            <div class="carousel">
               <img src="image/main3.jpeg">
               <img src="image/main2.jpeg">
               <img src="image/main1.jpeg">
            </div>
            <div class="hwr">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
                  <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
               </svg>
            </div>
            <h3><i class="fad fa-cake"></i> <span class="p">Welcome</span> guys</h3>
            <h4>what is ROMIANI?</h4>
            <p>
               Genießen Sie jeden Moment mit uns
            </p>
            <a class="btn" href="#">
               <span>Order Now</span>
               <i class="fad fa-angle-right"></i>
            </a>
         </section>
         <!-- about -->
         <section>
            <div class="carousel">
               <img src="image/main4.jpeg">
               <img src="image/main5.jpeg">
               <img src="image/main6.jpeg">
            </div>
            <div class="hwr">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
                  <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
               </svg>
            </div>
            <h3><i class="fad fa-user-chef"></i> <span class="p">About</span> Us</h3>
            <h4>warum wir?</h4>
            <p>
               Wir sind, was Sie brauchen
            </p>
            <a class="btn" href="#">
               <span>Order Now</span>
               <i class="fad fa-angle-right"></i>
            </a>
         </section>
         <!-- home -->
         <section>
            <div class="carousel">
               <img src="image/main3.jpeg">
               <img src="image/main2.jpeg">
               <img src="image/main1.jpeg">
            </div>
            <div class="hwr">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
                  <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
               </svg>
            </div>
            <h3><i class="fad fa-cake"></i> <span class="p">Welcome</span> guys</h3>
            <h4>what is ROMIANI?</h4>
            <p>
               Genießen Sie jeden Moment mit uns
            </p>
            <a class="btn" href="#">
               <span>Order Now</span>
               <i class="fad fa-angle-right"></i>
            </a>
         </section>
         <!-- about -->
         <section>
            <div class="carousel">
               <img src="image/main4.jpeg">
               <img src="image/main5.jpeg">
               <img src="image/main6.jpeg">
            </div>
            <div class="hwr">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
                  <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
               </svg>
            </div>
            <h3><i class="fad fa-user-chef"></i> <span class="p">About</span> Us</h3>
            <h4>warum wir?</h4>
            <p>
               Wir sind, was Sie brauchen
            </p>
            <a class="btn" href="#">
               <span>Order Now</span>
               <i class="fad fa-angle-right"></i>
            </a>
         </section>
      </article>
      <!-- menu -->
      <br>
      <h2 class="c"><i class="fad fa-list"></i> Our <span class="p">Menu</span></h2>
      <br>
      <hr class="dash"> <br>
      <!-- menu-box -->
      <article class="menu-box">
         <form id="filter" oninput="formFilter(this)" method="dialog" class="filter">
            <input type="checkbox" name="cafe" class="text">
            <input type="checkbox" name="drink" class="text">
            <input type="checkbox" name="cake" class="text">
            <input type="checkbox" name="candy" class="text">
         </form>
         <div class="cards">
            <div class="menu-card loading"></div>

         </div>
         <div class="next-back">
            <button disabled id="back-btn" onclick="Back()">zurück</button>
            <button id="next-btn" onclick="Next()">Nächstes</button>
         </div>
      </article>
   </main>
   <!-- footer -->
   <footer>
      <div class="flex">
         <div class="flex-col">
            <div>
               <h2>Location</h2>
            </div>
            <div>
               <p>adress</p>
            </div>
         </div>
         <div class="flex-col">
            <div>
               <h2>Quick Link</h2>
            </div>
            <div>
               <a href="#Home">home</a>
               <a href="#About">About </a>
               <a href="./foodmenu.php">Menu</a>
            </div>
         </div>
         <div class="flex-col">
            <div>
               <h2>Contact</h2>
            </div>
            <div>
               <div class="flex-nowrap">
                  <span><i class="fad fa-phone"></i></span>
                  <span>:phone</span>
               </div>
               <div class="flex-nowrap">
                  <span><i class="fad fa-envelope"></i></span>
                  <span>: Info@email.com</span>
               </div>
            </div>
         </div>
         <div class="follows">
            <div>
               <h2>Follows</h2>
            </div>
            <div>
               <i class="fa-brands fa-facebook-f"></i>
               <i class="fa-brands fa-twitter"></i>
               <i class="fa-brands fa-instagram"></i>
               <i class="fa-brands fa-linkedin-in"></i>
            </div>
         </div>
      </div>
      <br>
      <hr class="dash">
      <div>
         <p class="end">Design by <span><i class="fad fa-bug"></i> Team Bugactiviti</span></p>
      </div>
   </footer>
   <!-- Alert -->
   <div id="product">
      <alert-backdrop></alert-backdrop>
      <alert name="product">
         <alert-header id="alert-product-name">Name</alert-header>
         <alert-body>
            <div class="pad">
               <div><img class="rad" id="alert-product-profile"></div>
            </div>
            <hr>
            <div class="pad">
               <div style="display: inline-block; padding: 5px" id="alert-product-info"></div>
               <span class="badge primary" id="alert-product-price"></span>
               <span class="badge" id="alert-product-type"></span>
            </div>
         </alert-body>
         <alert-footer class="flex">
            <button onclick="CloseAlert('product')">Ok</button>
         </alert-footer>
      </alert>
   </div>
   <!-- script -->
   <script src="script/main.js"></script>
   <script src="script/ripple.js"></script>
   <script>
      var numberPage = 1;
      var json = null;

      function Fetch(num) {
         var nextBtn = document.querySelector('#next-btn');
         var backBtn = document.querySelector('#back-btn');
         var data = { "req_m": "get_lp", "page": num }
         var data2 = { "req_m": "get_lp", "page": num + 1 }
         var data3 = '...'
         fetch("call.php", {
               method: 'POST',
               headers: {
                  'Content-Type': 'application/json',
               },
               body: JSON.stringify(data)
            })
            .then(x => x.json())
            .then(y => {
               json = y;
               card(y);
            });

         fetch("call.php", {
               method: 'POST',
               headers: {
                  'Content-Type': 'application/json',
               },
               body: JSON.stringify(data2)
            })
            .then(x => x.json())
            .then(y => {
               if (true) {
                  if (Object.keys(y[0]).length = 4)
                     nextBtn.disabled = false;
               } else {
                  nextBtn.disabled = true;
               }
            })
            .catch(err => {
               nextBtn.disabled = true;
            });
         if (num > 1) {
            backBtn.disabled = false;
         } else {
            backBtn.disabled = true;
         }
      }
      Fetch(numberPage);
      function Next() {
         numberPage = numberPage + 1;
         Fetch(numberPage);
      }
      function Back() {
         numberPage = numberPage - 1;
         Fetch(numberPage);
      }
      function card(obj) {
         var elm = document.querySelector('.menu-box>.cards');
         elm.innerHTML = '';
         for (i in obj) {
            elm.innerHTML += `
            <div onclick="ShowInfo(${i})" style="animation: show 0.3s 0.${i}s both" class="menu-card">
               <div class="ripple-p menu-img">
                  <img src="${obj[i].profile}">
               </div>
               <div class="menu-info">
                  <h2>${obj[i].pname}</h2>
                  <hr>
                  <p>${obj[i].pdescribe}</p>
                  <br>
               </div>
            </div>`;
         }
         Ripple();
      }
      // filter
      function formFilter(x) {
         const formData = new FormData(x);
         const obj = {};
         var all = x.querySelectorAll('input');
         all.forEach(elm=>{
            obj[elm.name] = elm.checked;
         });
         
         console.log(obj)
         
      }


      formFilter(document.querySelector('form#filter'))
      // alert 
      function ShowInfo(index) {
         var name = document.querySelector('#alert-product-name');
         var profile = document.querySelector('#alert-product-profile');
         var info = document.querySelector('#alert-product-info');
         var price = document.querySelector('#alert-product-price');
         var type = document.querySelector('#alert-product-type');

         var data = json[index];
         name.innerHTML = data.pname;
         profile.src = data.profile;
         info.innerHTML = data.pdescribe;
         price.innerHTML = data.price;
         type.innerHTML = data.type;
         Alert('product')
      }
   </script>
</body>

</html>
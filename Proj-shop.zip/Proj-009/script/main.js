// Theme
function Mode() {
  var storage = JSON.parse(localStorage.getItem('mushroom'));
  var darkmode;
  if (storage == undefined) {
    darkmode = true;
    localStorage.setItem('mushroom', JSON.stringify({
      mode: darkmode
    }));
  } else {
    darkmode = storage.mode;
  }
  document.querySelector('#darkmode').checked = darkmode;
  return darkmode;
}
function Darkmode() {
  M.toggleMode(x);
  localStorage.setItem('mushroom', JSON.stringify({
    mode: M.darkmode
  }));
   document.querySelector('#darkmode').checked = M.darkmode;
  Freeze(10);
  Statusbar();
}
function Statusbar() {
  var TC = document.querySelector('meta[name="theme-color"]');
  TC.setAttribute('content', M.themeColor.background);
}
function Freeze(x) {
   var all = document.querySelectorAll('*,*:after,*:before');
   all.forEach(elm => {
      elm.style.setProperty('transition', '0s');
   });
   setTimeout(() => {
      all.forEach(elm => {
         elm.style.removeProperty('transition');
      });
   }, x);
}
let M = Mushroom({
   color: 'hsl(30,100%,0%)',
   darkmode: Mode(),
   hasPalette: true,
   parts: [5,10,15,30,70]
});
Statusbar();
// Show 
function Show(x, y = 'show') {
   if (!x.classList.contains(y)) {
      x.classList.add(y);
   }
}
function Hide(x, y = 'show') {
   if (x.classList.contains(y)) {
      x.classList.remove(y);
   }
}
// Alert 
function Alert(x){
   var alr = document.querySelector(`alert[name="${x}"]`);
   var backdropAlr = document.querySelector('backdrop');
   Show(alr);
   Show(backdropAlr);
}
function CloseAlert(x){
   var alr = document.querySelector(`alert[name="${x}"]`);
   var backdropAlr = document.querySelector('backdrop');
   Hide(backdropAlr);
   Hide(alr);
}
// Menu
function Menu() {
   var menu = document.querySelector('menu');
   var menuBackdrop = document.querySelector('backdrop');
   Show(menu);
   Show(menuBackdrop);
   menuBackdrop.onclick = () => {
      Hide(menu);
      Hide(menuBackdrop);
   }
}
<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' and isset($_FILES['profile']) and isset($_POST['name']) and isset($_POST['info']) and isset($_POST['price']) and isset($_POST['type']) and isset($_POST['oldName']) ) {
    if($_FILES["profile"]["error"] == 0){
        $errors= array();
        $file_name = $_FILES['profile']['name'];
        $file_size = $_FILES['profile']['size'];
        $file_tmp = $_FILES['profile']['tmp_name'];
        $file_type = $_FILES['profile']['type'];
        $tmp = explode('.', $file_name);
        $file_ext = end($tmp);
        
        $extensions= array("jpeg","jpg","png");
    
      $cors = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u'.'w','x','y','z','_');
      $in = [array_rand($cors)][0];
      $name = '';
      while($in != -1){
          if($in%2 == 0){
              $name.=$cors[$in];
          }
          else{$name.=(strtoupper($cors[$in]));}
          $in--;
      } 
      $in = [array_rand($cors)][0];
      $name .= '_';
      while($in != -1){
          if($in%2 == 0){
              $name.=$cors[$in];
          }else{
              $name.=(strtoupper($cors[$in]));
          }
          $in--;
      }
		move_uploaded_file($file_tmp,"images/".$name.'.'.$file_ext);
		$name = "images/".$name.'.'.$file_ext;
    
        }else{$name = $_POST['p'];}
try {
    $mysqli =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
    $mysqli->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(PDOException $f){
    echo $f->getMessage();
}
    $q = 'update products  set pname = ? , pdescribe = ? , profile = ? , price = ? ,type = ? where pname = ?;';
    $st = $mysqli->prepare($q);
    $st->bindValue(1,$_POST['name'],PDO::PARAM_STR);
    $st->bindValue(2,$_POST['info'],PDO::PARAM_STR);
    $st->bindValue(3,$name,PDO::PARAM_STR);
    $st->bindValue(4,$_POST['price'],PDO::PARAM_STR);
    $st->bindValue(5,$_POST['type'],PDO::PARAM_STR);
    $st->bindValue(6,$_POST['oldName'],PDO::PARAM_STR);
    try{
        $st->execute();
        echo json_encode("ok");
    }catch(PDOException $f){echo json_encode("error");}
} else {
    echo json_encode(['status' => 'error', 'message' => 'error']);
}

?>
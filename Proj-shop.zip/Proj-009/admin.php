<?php 
include "org.php";
if(istrue($_COOKIE['cookie'])){}
else{
   echo '<script>window.location.href = "login.php";</script>';
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
   <title> Admin Panel </title>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <meta name="theme-color">
   <!-- style -->
   <link rel="stylesheet" href="style/style.css">
   <link rel="stylesheet" href="style/font-awesome/css/all.min.css">
   <!-- script -->
   <script src="script/Mushroom.min.js"></script>
</head>
<body>
   <!-- header -->
   <header>
      <div>
         <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000">
            <path fill="currentColor" d="M183.33,825L183.33,425C183.33,375,133.33,325,83.33,325L83.33,725C83.33,775,133.33,825,183.33,825z" />
            <path fill="currentColor" d="M216.67,825L216.67,425C216.67,375,266.67,325,316.67,325L316.67,725C316.67,775,266.67,825,216.67,825z" />
            <path fill="currentColor" d="M783.33,825L783.33,425C783.33,375,733.33,325,683.33,325L683.33,725C683.33,775,733.33,825,783.33,825z" />
            <path fill="currentColor" d="M816.67,825L816.67,425C816.67,375,866.67,325,916.67,325L916.67,725C916.67,775,866.67,825,816.67,825z" />
            <path fill="var(--primary)" d="M483.33,825L483.33,275C483.33,225,433.33,175,383.33,175L383.33,725C383.33,775,433.33,825,483.33,825z" />
            <path fill="var(--primary)" d="M516.67,825L516.67,275C516.67,225,566.67,175,616.67,175L616.67,725C616.67,775,566.67,825,516.67,825z" />
         </svg>
         <div><span class="p">A</span>dmin-<spam>P</spam>anel</div>
      </div>
      <div>
         <div onclick="Darkmode()" class="ripple-p ic desx">
            <i class="fad fa-moon-over-sun"></i>
         </div>
         <div onclick="Menu()" class="ripple-p ic">
            <i class="fad fa-bars"></i>
         </div>
      </div>
   </header>
   <!-- backdrop -->
   <backdrop id="menuBackdrop"></backdrop>
   <!-- menu -->
   <menu>
      <menu-header>
         <div class="color"></div>
         <div class="title">
            ROMIANI
         </div>
      </menu-header> <menu-body>
         <div class="list">
            <label class="ripple-p" oninput="Darkmode()"> <span><span class="p">D</span>arkmode</span> <input id="darkmode" type="checkbox" class="switch"> </label>
         </div>
         <div class="hwr">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
               <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
            </svg>
         </div>
         <div class="list">
            <a class="ripple">
               <span> <span class="p">T</span>elegram </span> <i class="fab fa-telegram"></i>
            </a>
            <a class="ripple">
               <span><span class="p">X</span> (<span class="p">T</span>witter)</span>
               <i class="fab fa-x-twitter"></i>
            </a>
            <a class="ripple">
               <span><span class="p">I</span>nstagram</span>
               <i class="fab fa-instagram"></i>
            </a>
            <a class="ripple">
               <span><span class="p">F</span>acebook</span>
               <i class="fab fa-facebook-f"></i>
            </a>
            <a class="ripple">
               <span><span class="p">L</span>inkedin <span class="p">I</span>n</span>
               <i class="fab fa-linkedin-in"></i>
            </a>
         </div>
         <div class="hwr">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
               <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
            </svg>
         </div>
         <div class="list">
            <a class="ripple">
               <span><span class="p">E</span>mail</span>
               <i class="fas fa-envelope"></i>
            </a>
            <a class="ripple">
               <span><span class="p">P</span>hone <span class="p">N</span>umber</span>
               <span class="fa fas fa-phone"></span>
            </a>
         </div>
         <div class="hwr">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.0 10.0">
               <path fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" d="M1.25,5.00Q5.31,0.00,9.38,5.00Q13.44,10.00,17.50,5.00Q21.56,0.00,25.63,5.00Q29.69,10.00,33.75,5.00Q37.81,0.00,41.88,5.00Q45.94,10.00,50.00,5.00Q54.06,0.00,58.13,5.00Q62.19,10.00,66.25,5.00Q70.31,0.00,74.38,5.00Q78.44,10.00,82.50,5.00Q86.56,0.00,90.63,5.00Q94.69,10.00,98.75,5.00"></path>
            </svg>
         </div>
         <div>
            <button class="error full"> Exit </button>
         </div>
      </menu-body>
   </menu>
   <!-- main -->
   <main style="margin-top: 70px">
      <!-- menu-box -->
      <article class="menu-box">
         <div class="cards"></div>
         <div class="next-back">
            <button disabled id="back-btn" onclick="Back()">Back</button>
            <button id="next-btn" onclick="Next()">Next</button>
         </div>
      </article>
   </main>
   <!-- Alert -->
   <div id="alerts">
      <alert-backdrop></alert-backdrop>
      <alert name="add">
         <alert-header>Add</alert-header>
         <alert-body>
            <form id="add-form" method="dialog">
               <label class="file-label">
                  <input name="profile" onchange="Change()" multiple="false" hidden type="file" name="upload-image" id="upload-image">
                  <div id="preview"><i class="fad fa-plus"></i></div>
               </label>
               <br>
               <div>
                  <input class="name" name="name" type="text" placeholder="Name">
               </div>
               <div class="flex">
                  <input class="type" name="type" type="text" placeholder="Type">
                  <input class="price" name="price" type="number" placeholder="Price">
               </div>
               <div>
                  <textarea class="info" name="info" cols="30" rows="10"></textarea>
               </div>
            </form>
         </alert-body>
         <alert-footer class="flex">
            <button class="tonal" onclick="CancelUploadImage()">Cancel</button>
            <button onclick="SaveNewCard()">Save</button>
         </alert-footer>
      </alert>
      <alert name="edit">
         <alert-header>Edit</alert-header>
         <alert-body>
            <form id="edit-form" method="dialog">
               <label class="file-label">
                  <input name="profile" onchange="Change2()" multiple="false" hidden type="file" id="upload-image">
                  <div id="preview2"><img></div>
               </label>
               <br>
               <div>
                  <input class="name" name="name" type="text" placeholder="Name" value="New Cake">
               </div>
               <div class="flex">
                  <input class="type" name="type" type="text" placeholder="Type" value="Cake">
                  <input class="price" name="price" type="number" placeholder="Price" value="11.00">
               </div>
               <div>
                  <textarea class="info" name="info" cols="30" rows="10"> A new cake for new year</textarea>
               </div>
            </form>
         </alert-body>
         <alert-footer class="flex">
            <button class="tonal" onclick="CloseAlert('edit')">Cancel</button>
            <button onclick="EditCars()">Save</button>
         </alert-footer>
      </alert>
      <alert name="del">
         <alert-icon class="error"><i class="fad fa-warning"></i></alert-icon>
         <alert-header>Warning</alert-header>
         <alert-body>
            <div class="pad">
               <p>You want delete it?</p>
            </div>
         </alert-body>
         <alert-footer class="flex">
            <button class="tonal" onclick="CloseAlert('del')">Cancel</button>
            <button class="error" onclick="DeleteCard()">Delete</button>
         </alert-footer>
      </alert>
      <alert name="ok">
         <alert-icon class="primary"><i class="fad fa-check"></i></alert-icon>
         <alert-header> Successful </alert-header>
         <alert-body>
            <div class="pad">
               <p> Mission Accomplished! </p>
            </div>
         </alert-body>
         <alert-footer class="flex">
            <button onclick="CloseAlert('ok')">OK</button>
         </alert-footer>
      </alert>
   </div>
   <script src="script/main.js"></script>
   <script src="script/ripple.js"></script>
   <!--<script>
      var numberPage = 1;
      var json;
      var oldName;
	  var p ;
      function Fetch(num){
         var nextBtn = document.querySelector('#next-btn');
         var backBtn = document.querySelector('#back-btn');
         var data = {"req_m":"get_lp","page":num};
      var data2 = {"req_m":"get_lp","page":num+1};
         fetch(`call.php`, {
         method: 'POST', 
         headers: {
            'Content-Type': 'application/json',
         },
         body: JSON.stringify(data)})
            .then(x => x.json())
            .then(y => {
               card(y);
               json = y;
            });
         fetch(`call.php`, {
         method: 'POST', 
         headers: {
            'Content-Type': 'application/json',
         },
         body: JSON.stringify(data2)})
            .then(x => x.json())
            .then(y => {
               nextBtn.disabled = false;
            })
            .catch(err => {
               nextBtn.disabled = true;
            });
         if(num > 1) {
            backBtn.disabled = false;
         } else {
            backBtn.disabled = true;
         }
      }
      Fetch(numberPage);
      function Next(){
         numberPage = numberPage+1;
         Fetch(numberPage);
      }
      function Back(){
         numberPage = numberPage-1;
         Fetch(numberPage);
      }
      function card(obj) {
         var elm = document.querySelector('.menu-box>.cards');
         elm.innerHTML = '';
         for (i in obj) {
            elm.innerHTML += `
            <div style="animation: show 0.3s 0.${i}s both" class="menu-card">
               <div class="ripple-p menu-img">
                  <img src="${obj[i].profile}">
               </div>
               <div onclick="DeleteButton(${i},'${obj[i].pname}')" class="ic del"><i class="fas fa-trash"></i></div>
               <div onclick="EditButton(${i})" class="ic edit"><i class="fas fa-pen"></i></div>
               <div class="menu-info">
                  <h2>${obj[i].pname}</h2>
                  <hr>
                  <p>${obj[i].pdescribe}</p>
                  <br>
               </div>
            </div>`;
         }
         elm.innerHTML += `
            <div onclick="Alert('add')" style="animation: show 0.3s 0.${i}s both" class="ripple-p menu-card-add">
               <div><i class="fad fa-plus"></i></div>
            </div>`;
         Ripple();
      }
      // upload image
      function Change(){
         var reader = new FileReader();
         reader.readAsDataURL(event.currentTarget.files[0])
         reader.onload = () => {
            var data = reader.result;
            var div = document.querySelector('#preview');
            div.innerHTML = `<img src="${data}">`
         }
      }
      function Change2(){
         var reader = new FileReader();
         reader.readAsDataURL(event.currentTarget.files[0])
         reader.onload = () => {
            var data = reader.result;
            var div = document.querySelector('#preview2');
            div.innerHTML = `<img src="${data}">`
			p = data;
         }
      }
      function CancelUploadImage(){
         var div = document.querySelector('#preview');
         div.innerHTML = `<i class="fad fa-plus">`;
         CloseAlert('add');
      }
      function SaveNewCard(){
         var form = document.querySelector('#add-form');
         var formData = new FormData(form);
         console.table(formData)

         fetch("xxx.php",{
            "method": "POST",
            "body": formData
         }).then(x => x.json()).then(y => {
            if(y == "ok"){
				window.location.reload();
			}
         })

         
         CloseAlert('add');
         var index = Number(document.querySelector('alert[name="edit"]').getAttribute('index'));
         Alert('ok');
      }
      // delete
      function DeleteButton(i,pname){
         Alert('del');
         document.querySelector('alert[name="del"]').setAttribute('index',i);
         document.querySelector('alert[name="del"]').setAttribute("pname",pname);
         document.querySelector('alert[name="del"]>alert-body>.pad').innerHTML = `you want delete card number <b>${i}</b>`;
      }
      function DeleteCard(){
         CloseAlert('del');
         var index = Number(document.querySelector('alert[name="del"]').getAttribute('index'));
         var pname = (document.querySelector('alert[name="del"]').getAttribute('pname'));

         var data = {"req_m":"delete_product","pname": pname}
         fetch("call.php", {
            method: 'POST', 
            headers: {
               'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
         })
         .then(x => x.json())
         .then(y => {window.location.reload()});
         Alert('ok');
      }
      // edit
      function EditButton(index){
         document.querySelector('alert[name="edit"]').setAttribute('index',index);
         var name = document.querySelector('alert[name="edit"] .name');
         var profile = document.querySelector('alert[name="edit"] img');
         var info = document.querySelector('alert[name="edit"] .info');
         var price = document.querySelector('alert[name="edit"] .price');
         var type = document.querySelector('alert[name="edit"] .type');
         var data = json[index];
         name.value = data.pname;
         profile.src = data.profile;
         info.value = data.pdescribe;
         price.value = data.price;
         type.value = data.type;
         oldName = data.pname;
		  p = data.profile;
         Alert('edit');
      }
      function EditCars(){
         var form = document.querySelector('#edit-form');
         var formData = new FormData(form);
         formData.append("oldName",oldName);
		  formData.append("p",p);
         console.table(formData);
         fetch("xx2.php",{
            "method": "POST",
            "body": formData
         }).then(x => x.json()).then(y => {
            if(y == "ok"){
				window.location.reload();
			}
         })

         
         CloseAlert('edit');
         var index = Number(document.querySelector('alert[name="edit"]').getAttribute('index'));
         Alert('ok');
      }
   </script>-->
</body>
</html>
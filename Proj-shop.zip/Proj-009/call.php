<?php 
// include "reset.php";
// include "gem.php";
include 'org.php';

$data = json_decode(file_get_contents('php://input'), true);


switch ($data['req_m']){
    case "login":
        if(isset($data['info'])){
            singin($data['user'],$data['pass']);
        }
        break;
     case "reset_now":
        if(isset($data['newpass']) and isset($data['code'])){
            resertnew($data['newpass'],$data['code']);
        }
        break;
    case "update_pass":
        if(isset($data['email'])){
            update_pass($data['email']);
        }
        break;
    case 'get_lp':
        if(isset($data['page'])){
            print_r(get_lp($data['page']));
        }
        break;

    break;
    case 'delete_menu':
        if(isset($data['pname'])){
            deletemenu($data['pname']);
        }else{
            echo json_encode('bad req2');
        }
    break;
        break;
        case 'delete_product':
            if(isset($data['pname'])){
                deleteproduct($data['pname']);
            }
            break;
}


?>

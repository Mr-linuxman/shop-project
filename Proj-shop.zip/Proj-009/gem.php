<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
// date_default_timezone_set('Asia/Tehran');
function sendvc($em,$pass){
    if(1){
        $mail = new PHPMailer(true);
        $mail->isSMtp();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ashwduhjhwjxjtest@gmail.com';
        $mail->Password = 'cchvzytzvrrwjklh';
        $mail->SMTPSecurity = 'ssl';
        $mail->port = 465;
        $mail->setFrom('ashwduhjhwjxjtest@gmail.com');
        $mail->addAddress($em);
        $mail->isHTML(true);
        $mail->Subject = 'update password ';
        $mail->Body = 'your pass ==>'.$pass;
        $mail->send();
}}
$mysqli =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
$mysqli->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
function update_pass($email){
    global $mysqli;
    $q = 'select * from admin where Email = ?;';
    $st =$mysqli->prepare($q);
    $st->bindValue(1,$email,PDO::PARAM_STR);
    $st->execute();
    if(isset($st->fetchAll()[0])){
        $rc = rand(100000,999999);
        $mysqli2 =new PDO("mysql:host=127.0.0.1;dbname=products;charset=utf8mb4",'romi','nxMu834@5');
        $mysqli2->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $q = "insert into reset (email,pass,date) values (?,".$rc.",?);";
        $st2 = $mysqli2->prepare($q);
        $st2->bindValue(1,$email,PDO::PARAM_STR);
        $st2->bindValue(2,date("Y/m/d/H/i"),PDO::PARAM_STR);
        try{
            $st2->execute();
        }catch(PDOException $c){
            echo $c->getMessage();
            $q1 = 'select date from reset where email = ? ;';
            $st3 = $mysqli2->prepare($q1);
            $st3->bindValue(1,$email,PDO::PARAM_STR);
            $st3->execute();
            $date1 =  ($st3->fetchAll()[0][0]);
            $daar1 = (explode("/",$date1));
            $date2 = date("Y/m/d/H/i");
            $daar2 = explode("/",$date2);
            if($daar1[3] == $daar2[3]){
                $ekh =  $daar2[4] - $daar1[4];
                if($ekh < 5){
                    return('chek your email box');
                    die();
                }
            }
            $rc = rand(100000,999999);
            $q = "update reset set pass = $rc , date = ? where email = ? ;";
            $st = $mysqli2->prepare($q);
            $st->bindValue(1,date("Y/m/d/H/i"),PDO::PARAM_STR);
            $st->bindValue(2,$email,PDO::PARAM_STR);
            $st->execute();
        }
        sendvc($email,$rc);
        return("send");

    }else{
        return('User not found');
    }
}

?>
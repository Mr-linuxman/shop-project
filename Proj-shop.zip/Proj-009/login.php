
<!DOCTYPE html>
<html lang="en">
<head>
   <title> Login </title>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <meta name="theme-color">
   <!-- style -->
   <link rel="stylesheet" href="style/font-awesome/css/all.min.css">
   <link rel="stylesheet" href="style/login.css">
   <!-- script -->
   <script src="script/Mushroom.min.js"></script>
   <script>
      // Theme
      var TC = document.querySelector('meta[name="theme-color"]');
      let M = Mushroom({
         color: 'hsl(30,100%,0%)',
         darkmode: false,
      });
      TC.setAttribute('content', M.themeColor['primary-fixed-dim']);
      // Show 
      function Show(x, y = 'show') {
         if (!x.classList.contains(y)) {
            x.classList.add(y);
         }
      }
      function Hide(x, y = 'show') {
         if (x.classList.contains(y)) {
            x.classList.remove(y);
         }
      }
   </script>
</head>
<body>
   <!-- main -->
   <form method="post">
      <h2 class="c">Admin Panel</h2>
      <hr>
      <div>
         <input id="user" name="username" type="text" placeholder="username">
         <input id = "pass" name="password" type="password" placeholder="password">
      </div>
      <br>
      <a href="forgot.php">Forgot the password?</a>
      <button class="full" type="submit" > Login </button>
   </form >
   <!-- script -->
   <script src="script/ripple.js"></script>

   <?php 

include 'org.php';
if(isset($_POST['username']) and isset($_POST['password'])){
   if(singin($_POST['username'],$_POST['password']) == '"loged in"'){
      echo '<script>window.location.href = "admin.php";</script>';
   }else{
      echo '<body><script> var id = document.getElementById("user"); id.classList.add("error"); var id = document.getElementById("pass"); id.classList.add("error");</script></body>';
   }
}else{}

?>

</body>

</html>